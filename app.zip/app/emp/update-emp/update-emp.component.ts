import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {EmployeeDto} from '../../dto/EmployeeDto.model';
import { EmpService } from 'src/app/service/employeeService.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-update-emp',
  templateUrl: './update-emp.component.html',
  styleUrls: ['./update-emp.component.css']
})
export class UpdateEmpComponent implements OnInit {
  empForm:FormGroup;
  empDtoObj: EmployeeDto;
  submitted = false;
  constructor(private fb: FormBuilder,private empService:EmpService,public activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let para1;
    this.activatedRoute
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
       para1 = params['empId'];
      });
   alert(para1);
this.submitted=false;
    this.empForm
     = this.fb.group({
      'name': ['',[Validators.required,Validators.minLength(3)]],
      'salary': ['',Validators.required],
      'city': ['',Validators.required],
      'state':['',Validators.required],
      'empId':['',Validators.required],
      'addressId':['',Validators.required]
    });
    this.empService.getEmpById(para1).subscribe((data) => {
      alert("Employee record from DB !"+data.addressId);
      this.empForm.patchValue({name:data.name});
      this.empForm.patchValue({salary:data.salary});
      this.empForm.patchValue({city:data.city});
      this.empForm.patchValue({state:data.state});
      this.empForm.patchValue({empId:data.empId});
      this.empForm.patchValue({addressId:data.addressId});
  },
    err => {
      alert("Employee not updated !");
    },
    () => { console.log('Method Executed') }
  ); 
  
  }//end of ngOninit
  get f() { return this.empForm.controls; }

  
  updateEmp(emp:EmployeeDto) {//same identical property for the formcontrolname
    this.submitted=true;
    if(this.empForm.invalid){
      return ;
    }
    this.empService.updateEmployee(emp).subscribe((data) => {
        alert("Employee updated !");
    },
      err => {
        alert("Employee not updated !");
      },
      () => { console.log('Method Executed') }
    ); 
  }
}

