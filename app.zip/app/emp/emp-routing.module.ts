import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {ListEmpComponent} from './list-emp/list-emp.component';
import {SaveEmpComponent} from './save-emp/save-emp.component';
import {UpdateEmpComponent} from './update-emp/update-emp.component';
import { AuthService } from '../service/auth.service';
const routes: Routes = [
  { path: 'list', component:ListEmpComponent},
  { path: 'save', component: SaveEmpComponent },
  { path: 'update', component: UpdateEmpComponent,canActivate : [AuthService] }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmpRoutingModule { }
