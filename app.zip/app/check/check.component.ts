import { Component, OnInit } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {EmpService} from '../service/employeeService.component';
import {FileDto} from '../service/fileDto';
import {EmployeeDto} from '../dto/EmployeeDto.model';
@Component({
  selector: 'app-check',
  templateUrl: './check.component.html',
  styleUrls: ['./check.component.css']
})
export class CheckComponent implements OnInit {

  title = 'file-handling';
  studentForm: FormGroup;
  selectedFiles: FileList;  
  currentFileUpload: File;  
  EmpList:EmployeeDto[]=[];
  

  constructor(private fb: FormBuilder ,private fileService:EmpService,private employeeDto:EmployeeDto) { 

  }

  ngOnInit() {
    this.studentForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'fileName' : new FormControl(''),
        });
let e1:EmployeeDto;

}
    getFile(fileDto:FileDto){   //emp is the model class object
    
    this.fileService.getFile(fileDto).subscribe((res) => {
        window.location.href=res.fileDownloadUri;
    },
      err => {
        alert("No such File found");
      },
      () => { console.log('Method Executed') }
    );
          
        }

     selectFile(event) {  
          const file = event.target.files.item(0);
          var size = event.target.files[0].size;  
      if(size > 1000000)  
      {  
          alert("size must not exceeds 1 MB");  
           
      }  else{
        this.selectedFiles = event.target.files;  
        this.currentFileUpload = this.selectedFiles.item(0);
        this.fileService.uploadFile(this.currentFileUpload).subscribe((res) => {
         
          alert(res.fileDownloadUri);
      },
        err => {
          alert(" File upload fail");
        },
        () => { console.log('Method Executed') }
      );
      }

        }

}
