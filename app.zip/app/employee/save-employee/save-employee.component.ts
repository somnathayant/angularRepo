import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-employee',
  templateUrl: './save-employee.component.html',
  styleUrls: ['./save-employee.component.css']
})
export class SaveEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
