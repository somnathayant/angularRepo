export class EmployeeDto{
	 empId:number;
     addressId:number;
	 deptId:number;
	 name:String;
	 dob:Date;
	 salary:number;
	 city:String;
	 state:String;
	 pincode:number;
	 deptName:String;


}